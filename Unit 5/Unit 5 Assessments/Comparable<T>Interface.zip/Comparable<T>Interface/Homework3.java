
/**
 * Abstract class Homework - write a description of the class here
 * Basic Homework class has setter/getter methods for pages and type of Homework implements Comparable<T> interface
 * @author (Jeffrey Chiu)
 * @version (06/03/18)
 */
public abstract class Homework3 implements Comparable<Homework3>
{
    // instance variables - replace the example below with your own
    private int pagesRead;
    private String typeHomework;
    
    public Homework3(){
        this.pagesRead = 0;
        this.typeHomework = "None";
    }
    
    public void setHomework(String typeHomework){
        this.typeHomework = typeHomework;
    }
    
    public String getHomework(){
        return this.typeHomework;
    }
    public void setPages(int pagesRead){
        this.pagesRead = pagesRead;
    }
    public int getPages(){
        return this.pagesRead;
    }
    public int compareTo(Homework3 hw3){
      return this.getPages()-hw3.getPages(); 
    }
    
    public abstract void createAssignment(int p);
}
