
/**
 * Write a description of interface Processing here.
 * Basic interface for upcoming classes
 * @author (Jeffrey Chiu) 
 * @version (06/03/18)
 */
public interface Processing
{
    void doReading();
}
